CSS3有哪些新特性？

	CSS3实现圆角（border-radius），阴影（box-shadow），
	对文字加特效（text-shadow、），线性渐变（gradient），旋转（transform）
	transform:rotate(9deg) scale(0.85,0.90) translate(0px,-30px) skew(-9deg,0deg);//旋转,缩放,定位,倾斜
	增加了更多的CSS选择器  多背景 rgba 
	在CSS3中唯一引入的伪元素是::selection.
	媒体查询，多栏布局 nth-child经常作为找规律的布局
	border-image

	弹性盒 display : box     box-flex = 1

	animation:animations 2.5s ease-out forwards,animations3 1s ease-out 2.5s forwards;
	}
	@-webkit-keyframes animations{
	    0%{-webkit-transform:scale(0);opacity:0;}
	    40%{-webkit-transform:scale(1);opacity:1;}
	    100%{opacity:1;}
	}

	兼容性问题：-o,-moz,-webkit,-ms,

	
自定义字体 @font-face 




